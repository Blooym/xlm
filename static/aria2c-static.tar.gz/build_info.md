## Build Info - x86_64-linux-musl With OpenSSL and zlib-ng
Building using these dependencies:
- zlib-ng: Version: 1.3.0.zlib-ng, source: https://github.com/zlib-ng/zlib-ng/archive/refs/tags/2.1.6.tar.gz
- xz: Version: 5.4.6, source: https://github.com/tukaani-project/xz/releases/download/v5.4.6/xz-5.4.6.tar.xz
- openssl: Version: 3.2.1, source: https://github.com/openssl/openssl/archive/refs/tags/openssl-3.2.1.tar.gz
- libxml2: Version: 2.11.8, source: https://download.gnome.org/sources/libxml2/2.11/libxml2-2.11.8.tar.xz
- sqlite: Version: 3.46.0, source: https://github.com/sqlite/sqlite/archive/release.tar.gz
- c-ares: Version: 1.29.0, source: https://c-ares.org/download/c-ares-1.29.0.tar.gz
- libssh2: Version: 1.11.0, source: https://libssh2.org/download/libssh2-1.11.0.tar.gz
- aria2: source: https://github.com/aria2/aria2/archive/master.tar.gz

aria2 version info:
```txt
aria2 version 1.37.0
Copyright (C) 2006, 2019 Tatsuhiro Tsujikawa

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

** Configuration **
Enabled Features: Async DNS, BitTorrent, Firefox3 Cookie, GZip, HTTPS, Message Digest, Metalink, XML-RPC, SFTP
Hash Algorithms: sha-1, sha-224, sha-256, sha-384, sha-512, md5, adler32
Libraries: zlib/1.3.0.zlib-ng libxml2/2.11.8 sqlite3/3.46.0 OpenSSL/3.2.0a c-ares/1.29.0 libssh2/1.11.0
Compiler: gcc 11.2.1 20211120
  built by  x86_64-pc-linux-gnu
  targeting x86_64-pc-linux-musl
  on        May 24 2024 15:34:10
System: Linux 5.15.0-107-generic #117-Ubuntu SMP Fri Apr 26 12:26:49 UTC 2024 x86_64

Report bugs to https://github.com/aria2/aria2/issues
Visit https://aria2.github.io/
```
